<?php
  require_once 'includes/common.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Mobiles | Web Store</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>
        <?php
        include 'includes/header.php';
        ?>
        <div class="container" id="content">
          
            <?php
              $result=mysqli_query($con,"select * from product_master where ptype='mobile'");
              if(mysqli_affected_rows($con))
              {
                  $x=1;
                  while($r=mysqli_fetch_assoc($result))
                  {
                      if($x==1)
                        echo "<div class='row text-center'>";
                      
                    echo "<div class='col-md-3 col-sm-6 home-feature'>";
                    echo "<div class='thumbnail'>";
                        echo"<a href='mobile_desc.php?pid=$r[pid]'><img src='$r[pimage]'></a>";
                        echo "<div class='caption'>";
                            echo "<h3>$r[pname]</h3>";
                            echo "<p>Price: Rs. $r[pprice] </p>";
                           
                                echo "<p><a href='login.php' role='button' class='btn btn-primary btn-block'>Buy Now</a></p>";
                        echo "</div>";
                    echo "</div>";
                echo "</div>";
                      $x++;
                      if($x==5)
                      {
                          echo "</div>";
                          $x=1;
                      }
                  }
              }
              else
              {
                  echo "<h2>Currently no product available</h2>";
              }
            ?>
                
            
        </div>

        <?php 
           include 'includes/footer.php'; 
        ?>
    </body>

</html>
