<?php
  require_once 'includes/common.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Mobiles | Web Store</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <style>
            .img1:hover{
             width: 500px;
             height: 500px;
           }
        </style>
    </head>

    <body>
        <?php
        include 'includes/header.php';
        ?>
        <div class="container" id="content">
          
        <?php
        $result=mysqli_query($con, "select * from product_master where pid=$_GET[pid]");
        $r=mysqli_fetch_assoc($result);
        echo "<div class='row'>";
            echo "<div class='col-sm-12'>";
              echo "<img src='$r[pimage]' class='img1'/>";
            echo "</div>";  
            
        echo "</div>";
            
        ?>
                
            
        </div>

        <?php 
           include 'includes/footer.php'; 
        ?>
    </body>

</html>


