<?php
require("includes/common.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Products | Web Store</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>
        <?php
        include 'includes/header.php';
        ?>
        <div class="container" id="content">
            <!-- Jumbotron Header -->
            <div class="jumbotron home-spacer" id="products-jumbotron">
                <h1>Welcome to our Web Store!</h1>
                <p>Smartphone lovers are on a constant hunt to buy the best smartphone at a reasonable price.</p>

            </div>
            <hr>

            <div class="row text-center" id="samsung">
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/1.png" alt="">
                        <div class="caption">
                            <h3>Samsung Galaxy</h3>
                            <p>Price: Rs. 7990.00 </p>
                           
                                <p><a href="<?php 
                                             
                                          if(!isset($_SESSION['name'])){
                                              echo "login.php";
                                          }
 
                                ?>" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/2.png" alt="">
                        <div class="caption">
                            <h3>Redmi Go</h3>
                            <p>Price: Rs. 6700.00 </p>
                                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/3.png" alt="">
                        <div class="caption">
                            <h3>Realme C3</h3>
                            <p>Price: Rs. 9999.00</p>
                          
                                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                            
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/4.png" alt="">
                        <div class="caption">
                            <h3>Nokia 2.3</h3>
                            <p>Price: Rs. 9099.00</p>
                                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
                        </div>
                    </div>
                </div>
            </div>

            <div class="row text-center" id="realme">
                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/5.png" alt="">
                        <div class="caption">
                            <h3>Samsung Galaxy 3</h3>
                            <p>Price: Rs. 9099.00 </p>
                            
                                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                  
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/6.png" alt="">
                        <div class="caption">
                            <h3>Realme C2</h3>
                            <p>Price: Rs. 6499.00 </p>
                            
                                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/7.png" alt="">
                        <div class="caption">
                            <h3>Oneplus 5</h3>
                            <p>Price: Rs. 15990.00 </p>
                         
                                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 home-feature">
                    <div class="thumbnail">
                        <img src="img/8.png" alt="">
                        <div class="caption">
                            <h3>Realme 5i</h3>
                            <p>Price: Rs. 10999.00 </p>
                                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                        
                        </div>
                    </div>
                </div>
            </div>



            </div>
            <hr>
        </div>

        <?php include("includes/footer.php"); ?>
    </body>

</html>
