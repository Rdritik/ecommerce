<?php
   include_once '../includes/common.php';
   $msg="";
   if(isset($_POST['submit']))
   {
       $uname=$_POST['e-mail'];
       $pwd=$_POST['password'];
       $query="select * from signup where emailid='$uname' and password='$pwd' and role='admin'";
       $result=mysqli_query($con, $query);
       if(mysqli_affected_rows($con)){
           $r=  mysqli_fetch_array($result);
           session_start();
           $_SESSION['name']=$r[name];
           header("location:product.php"); 
       }
     else{
       $msg="<strong><font color='red'>Invalid Email and Password!!!!!</font></strong>";
       }
   }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Webstore Admin Panel</title>
        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="../css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="../js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php
        include 'header.php';
        ?>
        <!--Header end-->

        <div class="container" id="content" style="margin-top: 50px">
         
            <div class="container-fluid decor_bg" id="login-panel">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <div class="panel panel-primary" >
                            <div class="panel-heading">
                                <h4>LOGIN</h4>
                                <?php echo $msg; ?>
                            </div>
                            <div class="panel-body">
                                <p class="text-warning"><i>Login to make a product entry</i><p>
                                <form method="POST">
                                    <div class="form-group">
                                        <input type="email" class="form-control"  placeholder="Email" name="e-mail" required = "true">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password" name="password" required = "true">
                                    </div>
                                    <button type="submit" name="submit" class="btn btn-primary">Login</button><br><br>
                                    
                                </form><br/>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!--Footer-->
        <?php
          include 'footer.php';
        ?>
        <!--Footer end-->
   
    </body> 
</html>