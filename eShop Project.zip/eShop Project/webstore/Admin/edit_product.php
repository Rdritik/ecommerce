<?php
   session_start();
   if(!isset($_SESSION['name'])){
    header("location:index.php");
   }
   include '../includes/common.php';
   if(isset($_GET['pid']))
   {
       $id=$_GET['pid'];
       
       $result=  mysqli_query($con, "select * from product_master where pid=$id");
       $r=  mysqli_fetch_array($result);
   }
   if(isset($_POST['update_product']))
   {
       
        $id=$_POST['txt_pid'];
        $name=$_POST['txt_pname'];
        $type=$_POST['txt_ptype'];
        $price=$_POST['txt_pprice'];
        if($_FILES['pimage']['name']!='')
        {
          $sou=$_FILES['pimage']['tmp_name'];
        $des=$_SERVER['DOCUMENT_ROOT']."/webstore/mobile/".$_FILES['pimage']['name'];
        move_uploaded_file($sou,$des);
        $path='mobile/'.$_FILES['pimage']['name'];
        $query="update product_master set pname='$name',ptype='$type',pprice='$price',pimage='$path' where pid=$id";
        }
        else
        {
        $query="update product_master set pname='$name',ptype='$type',pprice='$price'where pid=$id";
        }
        mysqli_query($con, $query);
        header("location:product.php");
   }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Webstore Admin Panel</title>
        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="../css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="../js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php
        include 'header.php';
        ?>
        <!--Header end-->

        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="page-header">Edit Product</h4>
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-4">
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Product ID</label>
                                <input type="text" name="txt_pid" readonly="" value="<?php if(isset($_GET['pid'])) echo $r[0];?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Name</label>
                                <input type="text" name="txt_pname" value="<?php if(isset($_GET['pid'])) echo $r[1];?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Type</label>
                                <input type="text" name="txt_ptype" value="<?php if(isset($_GET['pid'])) echo $r[2];?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Price</label>
                                <input type="text" name="txt_pprice" value="<?php if(isset($_GET['pid'])) echo $r[3];?>"class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Image</label>
                                <input type="file" name="pimage" class="form-control">
                            </div>
                            <input type="submit" name="update_product" value="Update Product"/>
                        </form>
                    </div>
                    <div class="col-md-4">
                        
                    </div>
                </div>
            </div>

        </div>
        
        <!--Footer-->
        <?php
          include 'footer.php';
        ?>
        <!--Footer end-->
   
    </body> 
</html>