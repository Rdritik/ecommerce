<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Product Admin Panel</title>
        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="../css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="../js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>
        <style>
            .btn1{
                width: 100px;
                background-color: grey;
                color: white;
                border-radius: 4px;
                
            }
            .btn1:hover{
                color: black;
            }
            
        </style>
    </head>
    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php
        include 'header.php';
        ?>
        <!--Header end-->

        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="page-header" style="border-bottom-color:greenyellow; border-width: 8px">Product Panel<br>Hello,<?php echo $_SESSION['name'];?></h4>
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="alert alert-success">
                            <a href="add_product.php">Add new Product</a>
                        </div>
                        
                    </div>
                    <div class="col-md-6">
                       
                    </div>
                </div>
                <div class="row">
                        <div class="col-sm-12">
                            <?php
                                    include '../includes/common.php';
                                    $result=mysqli_query($con,"select * from product_master");
                                    if(mysqli_affected_rows($con)>0){
                                        echo "<table class='table table-striped' width='100%'>";
                                        echo "<theader>List of Products:---</theader>";
                                        echo "<th>Product ID</th><th>Product Name</th><th>Product Type</th><th>Product Price</th><th>Product Image</th><th></th><th></th><th></th><th></th>"; 
                                        while($r=  mysqli_fetch_array($result)){
                                            echo "<tr>";
                                            echo "<td>$r[0]</td>";
                                            echo "<td>$r[1]</td>";
                                            echo "<td>$r[2]</td>";
                                            echo "<td>$r[3]</td>";
                                            echo "<td><img src='../$r[4]' width='60' height='60'/></td>";
                                            echo "<td><a href='edit_product.php?pid=$r[0]'><input type='button' value='Edit' class='btn1'/></a></td>";
                                            echo "<td><a href='delete.php?pid=$r[0]'><input type='button' value='Delete' class='btn1'/></a></td>";
                                            echo "<td><a href='add_product_desc.php?pid=$r[0]'><input type='button' value='Add Desc' class='btn1'/></a></td>";
                                            echo "<td><a href=''><input type='button' value='View Desc' class='btn1'/></a></td>";
                                            echo "</tr>";
                                        }
                                        echo "</table>";
                                    }else{
                                        echo '<h3>No Product Found!!!!!!</h3>';
                                    }
                            ?>  
                                  
                           
                        </div>
                    </div>
                
            </div>

        </div>
        
        <!--Footer-->
        <?php
          include 'footer.php';
        ?>
        <!--Footer end-->
   
    </body> 
</html>