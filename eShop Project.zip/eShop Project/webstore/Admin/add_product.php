<?php
    $msg="";
    session_start();
    if(!isset($_SESSION['name'])){
    header("location:index.php");
    }
    if(isset($_POST['add_product']))
    {
        $id=$_POST['txt_pid'];
        $name=$_POST['txt_pname'];
        $type=$_POST['txt_ptype'];
        $price=$_POST['txt_pprice'];
        $sou=$_FILES['pimage']['tmp_name'];
        $des=$_SERVER['DOCUMENT_ROOT']."/webstore/mobile/".$_FILES['pimage']['name'];
        move_uploaded_file($sou,$des);
        $path='mobile/'.$_FILES['pimage']['name'];
        include_once '../includes/common.php';
        
        $qry="insert into product_master values($id,'$name','$type',$price,'$path')";
        mysqli_query($con,$qry);
        if(mysqli_affected_rows($con)>0){
            $msg="<font color='green'>Product Added Successfully!!!!</font>";
        }
        else{
            $msg="<font color='red'>Error in adding Product!!!!</font>";
        }
        
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Webstore Admin Panel</title>
        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="../css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="../js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php
        include 'header.php';
        ?>
        <!--Header end-->

        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="page-header">Product</h4>
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-4">
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Product ID</label>
                                <input type="text" name="txt_pid" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Name</label>
                                <input type="text" name="txt_pname" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Type</label>
                                <input type="text" name="txt_ptype" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Price</label>
                                <input type="text" name="txt_pprice" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Product Image</label>
                                <input type="file" name="pimage" class="form-control">
                            </div>
                            <input type="submit" name="add_product" value="Add Product"/>
                            <?php echo $msg;?>
                        </form>
                    </div>
                    <div class="col-md-4">
                        
                    </div>
                </div>
            </div>

        </div>
        
        <!--Footer-->
        <?php
          include 'footer.php';
        ?>
        <!--Footer end-->
   
    </body> 
</html>