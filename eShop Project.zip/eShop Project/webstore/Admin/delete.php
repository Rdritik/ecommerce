<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:index.php");
}
$id=$_GET['pid'];
include '../includes/common.php';
mysqli_query($con, "delete from product_master where pid='$id'");
mysqli_query($con, "delete from mobile_desc where pid='$id'");
mysqli_close($con);
header("location:product.php");



?>

