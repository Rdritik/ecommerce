<?php
session_start();
if(!isset($_SESSION['name'])){
    header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Webstore Admin Panel</title>
        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="../css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="../js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top: 50px;">
        <!-- Header -->
        <?php
        include 'header.php';
        ?>
        <!--Header end-->

        <div id="content">
            <div class="container" style="margin-bottom: 10px">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="page-header" style="border-bottom-color: greenyellow; border-width: 8px;">ADD Product Descriptions</h4>
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-4">
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Product ID</label>
                                <input type="text" readonly="" name="txt_pid" value="<?php if(isset($_GET['pid'])) echo $_GET['pid'];?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Model Number</label>
                                <input type="text" name="txt_modelno" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Comapany Name</label>
                                <input type="text" name="txt_cname" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Processor</label>
                                <input type="text" name="txt_processor" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>RAM</label>
                                <input type="text" name="pram" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Screen Size</label>
                                <input type="text" name="pscreensize" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Storage</label>
                                <input type="text" name="pstorage" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Front Camera</label>
                                <input type="text" name="pfcamera" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Back Camera</label>
                                <input type="text" name="pbcamera" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Battery Capacity</label>
                                <input type="text" name="pbcapacity" class="form-control">
                            </div>
                            <input type="submit" name="add_product_desc" value="Add Product Description"/>
                          
                        </form>
                    </div>
                    <div class="col-md-4">
                        
                    </div>
                </div>
            </div>

        </div>
        
        <!--Footer-->
        <?php
          include 'footer.php';
        ?>
        <!--Footer end-->
   
    </body> 
</html>