<?php
require_once("includes/common.php");
session_start();
$msg="";
if (!isset($_SESSION['email'])) {
   header('location: index.php');
}
 else {
    

if(isset($_POST['submit'])){
$old_pass = $_POST['old-password'];
$new_pass = $_POST['password'];
$new_pass1 = $_POST['password1'];
$query = "SELECT emailid, password FROM signup WHERE emailid ='" . $_SESSION['email'] . "'";
$result = mysqli_query($con, $query)or die($mysqli_error($con));
$row = mysqli_fetch_array($result);
$orig_pass = $row['password'];

if ($new_pass != $new_pass1) {
    $msg="The new passwords is not  matching!!!!";
} else {
    if ($old_pass == $orig_pass) {
        $query = "UPDATE  signup SET password = '" . $new_pass . "' WHERE emailid = '" . $_SESSION['email'] . "'";
        mysqli_query($con, $query);
        $msg="Password Updated...";
    } else
       $msg="you entered wrong old password!!!!";
        
}
}
 }
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Settings | Webstore</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container-fluid" id="content">
            <div class="row">
                <div class="col-lg-4 col-lg-offset-4" id="settings-container">
                    <h4>Change Password</h4>
                    <form method="POST">
                        <div class="form-group">
                            <input type="password" class="form-control" name="old-password"  placeholder="Old Password" required = "true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="New Password" required = "true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password1"  placeholder="Re-type New Password" required = "true">
                        </div>
                        <button type="submit" class="btn btn-primary" name="submit">Change</button>
                         <br><?php echo $msg;?>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </body>
</html>