<footer>
    <div class="container">
        <center>
            <p>Copyright &copy; Web Store. All Rights Reserved  |  Contact Us: +91 90000 XXXXX</p>	
        </center>
    </div>
</footer>