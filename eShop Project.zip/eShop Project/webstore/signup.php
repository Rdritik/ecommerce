<?php
$msg="";
require("includes/common.php");
if(isset($_POST['submit']))
    {
        $name=$_POST['name'];
        $email=$_POST['e-mail'];
        $password=$_POST['password'];
        $gender=$_POST['gender'];
        $dob=$_POST['dob'];
        $phone=$_POST['phone'];
        
        
        $qry="insert into signup values('$name','$email','$password','$gender','$dob','$phone','client')";
        mysqli_query($con,$qry);
        if(mysqli_affected_rows($con)>0){
            header("location:login.php");
        }
        else{
            $msg="<font color='red'>Error!!!!</font>";
        }
        
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Signup | Web Store</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container-fluid decor_bg" id="content">
            <div class="row">
                <div class="container">
                    <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
                        <h2>SIGN UP</h2>
                        <form method="POST">
                            <div class="form-group">
                                <input class="form-control" placeholder="Name" name="name"  required = "true" pattern="^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control"  placeholder="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"  name="e-mail" required = "true"><?php echo INPUT_GET['m1']; ?>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="Password" pattern=".{6,}" name="password" required = "true">
                            </div>
                             <div class="form-group" style="border: 1px solid; border-radius: 5px; padding: 5px; border-color: #a6a6a6; color: #a6a6a6">
                                   Gender:<input type="radio" name="gender" value="Male"/>Male <input type="radio" name="gender" value="Male"/>Female
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control"  placeholder="DOB(1989-11-21)"  name="dob" required = "true">
                            </div>
                            <div class="form-group">
                                <input  type="number" class="form-control"  placeholder="Mobile Number" name="phone" maxlength="10" size="10" required = "true">
                            </div>
                            
                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php include "includes/footer.php"; ?>
    </body>
</html>