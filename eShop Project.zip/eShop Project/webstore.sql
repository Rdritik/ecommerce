-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 20, 2020 at 02:14 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `mobile_desc`
--

DROP TABLE IF EXISTS `mobile_desc`;
CREATE TABLE IF NOT EXISTS `mobile_desc` (
  `pid` int(11) NOT NULL,
  `model_no` varchar(30) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `processor` varchar(20) NOT NULL,
  `RAM` varchar(10) NOT NULL,
  `screen_size` varchar(10) NOT NULL,
  `storage` varchar(10) NOT NULL,
  `front_camera` varchar(10) NOT NULL,
  `back_camera` varchar(10) NOT NULL,
  `Battery_cap` varchar(15) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

DROP TABLE IF EXISTS `product_master`;
CREATE TABLE IF NOT EXISTS `product_master` (
  `pid` int(11) NOT NULL,
  `pname` varchar(30) NOT NULL,
  `ptype` varchar(30) NOT NULL,
  `pprice` int(11) NOT NULL,
  `pimage` varchar(60) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`pid`, `pname`, `ptype`, `pprice`, `pimage`) VALUES
(1001, 'Samsung ', 'Mobile', 15000, 'mobile/8.png'),
(1002, 'Real Me', 'Mobile', 13000, 'mobile/3.png'),
(1003, 'Redmi', 'Mobile', 8490, 'mobile/4.png'),
(1004, 'Samsung Galaxy', 'Mobile', 17999, 'mobile/5.png'),
(1005, 'Real me C1', 'Mobile', 6790, 'mobile/2.png'),
(1006, 'Nokia ', 'Mobile', 9990, 'mobile/4.png'),
(1007, 'Realme 2', 'Mobile', 8999, 'mobile/8.png'),
(1008, 'Oppo F11', 'Mobile', 15999, 'mobile/6.png');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

DROP TABLE IF EXISTS `signup`;
CREATE TABLE IF NOT EXISTS `signup` (
  `name` varchar(30) NOT NULL,
  `emailid` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `dob` date NOT NULL,
  `phone` bigint(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
